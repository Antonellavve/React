import axios from "axios";
import { errorFetchingProducts, fetchingProducts, successFetchingProducts } from "../Redux/Products/productsSlice";
import { BASE_URL } from "../utils/limitProducts";

export const createProduct = async (id, title, img, price, category, stock) => {
  try {
    //console.log("Creando producto con categoría:", category);

    const productData = {
      id,
      title,
      img,
      price,
      category: category.toUpperCase(),
      stock
    };

    //console.log("Datos del producto:", productData);

    const response = await axios.post(`${BASE_URL}/products`, productData);

    console.log("Respuesta del servidor:", response.data);
    return response.data;
  } catch (err) {
    console.error("Error al crear el producto:", err.response?.data);
    alert(err.response?.data.msg);
  }
};


export const loadProducts = async (dispatch) => {
  dispatch(fetchingProducts());
  try {
    const response = await axios.get(`${BASE_URL}/products`);
    const products = response?.data.products
      .map((product) => {
        const { _id, title, category, price, stock, img } = product;
        return {
          id: _id,
          title,
          category: category.code,
          price,
          img,
          stock,
        };
      });

    if (products) dispatch(successFetchingProducts(products));
      else dispatch(errorFetchingProducts(response.data.msg))
  } catch (error) {
    dispatch(errorFetchingProducts("Error al obtener productos de la base de datos"));
  }
};