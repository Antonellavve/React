import React, { useEffect, useState } from 'react';
import { Formik } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import Input from '../../components/UI/Input/Input';
import Submit from '../../components/UI/Submit/Submit';
import { ContainerOfProducts, Form } from './ProductsStyled';
import { ProductsInitialValues } from '../../formik/Values';
import { ProductsValidationSchema } from '../../formik/Validation';
import { useNavigate } from 'react-router-dom';
import { ADMIN } from '../../utils/limitProducts';
import { createProduct } from '../../axios/products.js';

const AddProduct = () => {
  const dispatch = useDispatch();
  const products = useSelector(state => state.products.products);
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    if (products && products.length > 0) {
      navigate('/productsAdd');
    } else {
      const user = JSON.parse(localStorage.getItem('user')); 
      if (user && user.rol !== ADMIN) {
        navigate('/heroCheck');
      }
    }
  }, [products, navigate]);

  return (
    <ContainerOfProducts>
      <h1>Agregar Producto</h1>
      {showModal && (
        <div className="modal">
          <div className="modal-content">
            <p>Producto agregado con éxito</p>
            <button onClick={() => setShowModal(false)}>Cerrar</button>
          </div>
        </div>
      )}
      <Formik
        initialValues={ProductsInitialValues}
        validationSchema={ProductsValidationSchema}
        onSubmit={async (values, actions) => {
          const userString = localStorage.getItem('user');
          const userObject = JSON.parse(userString);
          const token = userObject?.currentUser?.token;
          const productData = await createProduct(
            values.id,
            values.title,
            values.img,
            values.price,
            values.category,
            values.stock
          );
          if (productData) {
            dispatch(addNewProduct(productData));
            setShowModal(true);
            setTimeout(() => {
              setShowModal(false);
              navigate('/productsAdd');
            }, 3000); // Cerrar el modal después de 3 segundos, puedes ajustar este valor
          }
          actions.resetForm();
        }}
      >
        <Form>
          <Input name="id" type="text" placeholder="ID" />
          <Input name="title" type="text" placeholder="Título" />
          <Input name="img" type="text" placeholder="URL de la imagen" />
          <Input name="price" type="text" placeholder="Precio" />
          <Input name="category" type="text" placeholder="Categoría" />
          <Input name="stock" type="text" placeholder="Stock" />
          <Submit>Agregar Producto</Submit>
        </Form>
      </Formik>
    </ContainerOfProducts>
  );
};

export default AddProduct;
