import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { selectCategory } from '../../Redux/Categories/categoriesSlice';
import { addToCart } from '../../Redux/Cart/cartSlice';
import { formatPrice } from "../../utils/formatPrice";
import { ProductsSection, ContainerSelect, ProductsContainer, Card, Title } from './ProductsStyled';
import Submit from "../../components/UI/Submit/Submit";
import { LIMITE_INICIAL } from '../../utils/limitProducts';
import Button from '../../components/UI/Button/Button';
import { successFetchingProducts } from '../../Redux/Products/productsSlice'; // Importa la acción de éxito para la obtención de productos
import { loadProducts } from "../../axios/products";
import { addItem } from '../../Redux/Cart/cartUtils';
import { useNavigate } from 'react-router-dom';

    const Products = () => {
    const [limit, setLimit] = useState(LIMITE_INICIAL);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { currentUser } = useSelector((state) => state.user);

    const selectedCategory = useSelector((state) => state.categories.selectedCategory);
    const products = useSelector((state) => state.products.products);
    const totalProducts = useSelector((state) => state.products.totalProducts);

    useEffect(() => {
        setLimit(LIMITE_INICIAL);
    }, [selectedCategory]);

    const filteredProducts = selectedCategory
        ? products[selectedCategory] || []
        : products; // Ahora utilizamos los productos directamente del estado

    const handleShowMore = () => {
        // Aumentar el límite cuando se hace clic en "Ver más"
        setLimit((prevLimit) => prevLimit + 5);
    };

    const handleShowLess = () => {
        // Disminuir el límite cuando se hace clic en "Ver menos"
        setLimit((prevLimit) => prevLimit - 5);
    };

    const handleAddToCart = (product) => {
        // Agregar el producto al carrito utilizando la acción addToCart de Redux
        dispatch(addToCart(product));
    };

    const handleCategorySelect = (category) => {
        // Utiliza la acción selectCategory para cambiar la categoría seleccionada en el estado de Redux
        dispatch(selectCategory(category));
    };

    // Realiza la solicitud al backend para obtener productos cuando el componente se monta
    useEffect(() => {
        if (!products.length) {
        loadProducts(dispatch);
        }
    }, [dispatch]);

    return (
        <ProductsSection>
        <Title>
            <h2>Nuestros Productos</h2>
        </Title>

        <ContainerSelect>
            <button className={`category ${selectedCategory === 'Camperas' ? 'active' : ''}`} onClick={() => handleCategorySelect('Camperas')}>
            Camperas
            </button>
            <button className={`category ${selectedCategory === 'Pantalones' ? 'active' : ''}`} onClick={() => handleCategorySelect('Pantalones')}>
            Pantalones
            </button>
            <button className={`category ${selectedCategory === 'Remeras' ? 'active' : ''}`} onClick={() => handleCategorySelect('Remeras')}>
            Remeras
            </button>
            <button className={`category ${selectedCategory === 'RemeronesYVestidos' ? 'active' : ''}`} onClick={() => handleCategorySelect('RemeronesYVestidos')}>
            Vestidos
            </button>
            <button className={`category ${selectedCategory === 'Buzos' ? 'active' : ''}`} onClick={() => handleCategorySelect('Buzos')}>
            Buzos
            </button>
        </ContainerSelect>

        <ProductsContainer>
            {filteredProducts && filteredProducts.slice(0, limit).map((product) => {
            const { id, title, img, price } = product;
            return (
                <Card key={id}>
                <img src={img} alt={title} />
                <h2>{title}</h2>
                <span>{formatPrice(price)}</span>
                <Button onClick={() => {
                    if (!currentUser) {
                    navigate("/login");
                    } else {
                    dispatch(addItem({ id, title, img, price }));
                    }
                }}>
                    Comprar
                </Button>
                </Card>
            );
            })}
        </ProductsContainer>

        {!selectedCategory && (
            <div className="button-container">
            <Submit
                onClick={handleShowLess}
                disabled={limit <= LIMITE_INICIAL}
            >
                Ver menos
            </Submit>
            <Submit
                onClick={handleShowMore}
                disabled={limit >= totalProducts}
            >
                Ver más
            </Submit>
            </div>
        )}
        </ProductsSection>
    );
};

export default Products;
