export const LIMITE_INICIAL = 10;
export const THE_SHIPPING = 1400;
export const BASE_URL = 'https://proyecto-final-back-six.vercel.app';
export const ADMIN = 'Admin';
export const USER = 'User';