import { CounterStyled } from "./CounterStyles";

const Counter = ({children}) => {
    return <CounterStyled>{children}</CounterStyled>
};

export default Counter;