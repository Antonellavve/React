import React from "react";

const ButtonContainer = ({ children }) => {
    return (
        <div className="button-container">
            {children}
        </div>
    );
};

export default ButtonContainer;
