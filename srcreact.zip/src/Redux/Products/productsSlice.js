import { createSlice } from "@reduxjs/toolkit";
// import { products, totalProducts } from "../../data/products";

const INITIAL_STATE = {
  products: [],
  totalProducts: 0,
  isLoading: true,
  error: false
}

export const productsSlice = createSlice({
  name: "products",
  initialState: INITIAL_STATE,
  reducers: {
    getProducts: state => {
      return state.products;
    },
    fetchingProducts: ((state) => {
      return {
        ...state,
        isLoading: true,
      }
    }),
    successFetchingProducts: ((state, action) => {
      return {
        ...state,
        isLoading: false,
        error: false,
        products: [...action.payload],
      }
    }),
    errorFetchingProducts: ((state, action) => {
      return {
        ...state,
        isLoading: false,
        error: action.payload
      }
    })
  }
});

export const { getProducts, fetchingProducts, successFetchingProducts, errorFetchingProducts } = productsSlice.actions;
export default productsSlice.reducer;