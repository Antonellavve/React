export const checkoutValues = {
    name: '',
    cellphone: '',
    location: '',
    address: ''
}

export const registerInitialValues = {
    name: '',
    email: '',
    password: ''
}

export const loginInitialValues = {
    email: '',
    password: ''
}

export const validateInitialValues = {
    code: '',
  };

export const ProductsInitialValues = {
    title: '',
    category: '',
    price: '',
    stock: '',
};