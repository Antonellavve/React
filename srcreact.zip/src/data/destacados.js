export const recomendados = [
    {
        id: 1,
        title: "Buzo Ari",
        img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/img/Producto/53ea0b1d-2d46-b86d-2609-de0b6b849cb1/variantes/WhatsApp-Image-2023-06-10-at-10-02-06-1-648d9b7409c1c.webp",
        price: 5400,
        category: "Buzos",
    },
    {
        id: 2,
        title: "Remeron Seda",
        img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/img/Producto/fa3f8565-4954-e523-473b-0c29f46541cd/variantes/rem4-6474ff8ee663e.webp",
        price: 7500,
        category: "RemeronesYVestidos",
    },
    {
        id: 3,
        title: "Pantalon Sire Batik",
        img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/img/Producto/35a055da-15a0-6dda-323b-a68781185230/variantes/batp7-6474ef3a665b7.webp",
        price: 9800,
        category: "Pantalones",
    },
    {
        id: 4,
        title: "Buzo Edna",
        img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/img/Producto/b13ba782-f18e-c3bb-7012-658f6ccaf436/WhatsApp-Image-2023-05-29-at-10-36-34-64760b11ab451.webp",
        price: 4500,
        category: "Buzos",
    },
    {
        id: 5,
        title: "Remera Angel",
        img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/img/Producto/01a9f79b-12d7-28fc-e38b-b6fd8b19b31f/variantes/WhatsApp-Image-2023-04-21-at-14-11-21-e1682098210759-6476036addda7.webp",
        price: 4500,
        category: "Remeras",
    },
    {
        id: 6,
        title: "Top Mara",
        img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/img/Producto/a44beb34-1f5f-a4fa-0452-57532d48b2dd/variantes/WhatsApp-Image-2023-03-23-at-16-21-56-6475f52d5722a.webp",
        price: 5400,
        category: "Remeras",
    },
    {
        id: 7,
        title: "Campera Sire",
        img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/img/Producto/5b306fb3-ed0f-6467-7a03-1a3d281e7b0d/WhatsApp-Image-2023-04-18-at-09-48-40-6476023d77900.webp",
        price: 9500,
        category: "Campera",
    },
    {
        id: 8,
        title: "Calza Damero Gold",
        img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/img/Producto/7ccacfb2-8621-224e-6770-98c05855bcac/variantes/WhatsApp-Image-2023-05-16-at-14-11-49-647609eace3e6.webp",
        price: 5600,
        category: "Pantalones"
    },
    {
        id: 9,
        title: "Campera Lirio",
        img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/img/Producto/e96788c5-a249-4379-b576-dbad54b45ed7/WhatsApp-Image-2023-04-03-at-09-47-04-min-6475fcc6dcbe4.webp",
        price: 8500,
        category: "Campera"
    },
    {
        id: 10,
        title: "Calza Mara",
        img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/img/Producto/04fa53d5-fcd8-ffe3-f0cd-88c04970ee49/dep4-6475f471d6705.webp",
        price: 6800,
        category: "Pantalones"
    },
];
