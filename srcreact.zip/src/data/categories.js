export const categories = [
	{
		id: 1,
		img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/modulos/580x630-buzos-644978737eb6e.webp",
		title: "Buzos",
		category: "Buzos",
		
	},
	{
		id: 2,
		img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/modulos/580x630-camperas-64497874b7379.webp",
		title: "Camperas",
		category: "Camperas",
		
	},
	{
		id: 3,
		img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/modulos/640x640-pantalones-6449788daaba6.webp",
		title: "Pantalones",
		category: "Pantalones",
	},
	{
		id: 4,
		img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/modulos/640x640-remeras-6449788ec7631.webp",
		title: "Remeras",
		category: "Remeras",
	},
	{
		id: 5,
		img: "https://d28hi93gr697ol.cloudfront.net/d1f4550f-4906-4a3d/modulos/640x640-remeron-vestido-6449788fb501b.webp",
		title: "Remerones y Vestidos",
		category: "RemeronesYVestidos",
	},
];